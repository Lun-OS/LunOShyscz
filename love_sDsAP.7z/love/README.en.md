# Like_Girl V5.1.0

> No kidding, I updated it again...

- Demo address: [Demo](https://lovey.kikiw.cn)
- project documents address: [see document] (https://blog.kikiw.cn/index.php/archives/52/)
![Index](https://img.gejiba.com/images/15eee53f2c5653ffaf9612ad37202252.png)
![Admin](https://img.gejiba.com/images/fab78111e4f2d3ce9b240df39cf78e04.png)

### Foreword

* This project is completely free and capable friends can carry out secondary development
* Prohibited in any way to sell all consequences of their own responsibility against the original intention of the project author will be investigated
* The original intention of developing this program is to enrich our knowledge base and improve self-cultivation through in-depth learning and extensive communication
* If you can bring a little joy and pleasure to your partner in this process, it is undoubtedly an additional affirmation of my development and a gratifying thing


#### Project Statement


- In this update, I need to first clarify the recent hot incident "Love-Yi" couple station there is Sql injection vulnerability
- "Love-Yi" here is LikeGirl couple station. Why is it called "Love-Yi" because the title of the Demo site was released from the beginning
- Anyway, as for how I came to see the content of this public account article, one day my users forwarded this article in the communication group, but I saw that there was a dim sum cold at that moment
- But after all, I developed the program and I can tell it's not version 5.0 when I see the dots and injection points in the picture
- Why am I so sure because the dribs and dribs of id in 5.0 have been processed and will not report database errors at all when I see here I also feel speechless if there are no bugs in the previous version why do I keep updating but it doesn't matter
- I did spend a lot of time to update the version 5.0 of Lovers Station, but the technology at that time was limited and it could not be updated to a very perfect one, which could only guarantee the normal operation and use without error
- But I also never dare to promise that this program is absolutely safe Bug number is zero, I still believe that there is no absolutely safe system this movie also watched lol
- Pull so much here I say that in fact, the 5.0 version of the lovers station does have more bugs, whether it is security issues or the Ui of the page
- Actually, I still don't know how many users are using it, but I have 1000+ comments on my blog document. I don't know if there are any repeated downloads of code cloud data compression package downloads of 1700+
- When I saw the data, I didn't want to waste the project. I wanted to pick it up and maintain it for a better ending.
- I need to thank so many users who like LikeAgirl app, and thank you for your sponsorship and support. I am just a full interest developer, not a big guy, and try my best to update it
- Finally, I would like to thank the user who submitted the vulnerability report of Likeagirl program for adding my wechat account and sending me the report of a document. I am worried and moved because the program may be used by many people in case the privacy content is really leaked by criminals, which is irreversible
- Because of this and I personally think that version 5.0 can continue to be optimized, but I have developed the Pro version for a fee and I have no energy to maintain the 5.0 version. I just want to devote my free time to the development of the Pro version and do not want to spend time on the open source version because the open source project can stick to the end of the project is really too few

## Rivers and lakes long road we will meet again (2024/06/14)



### LikeGirl 5.1.0

- Adjust the front-end dribble page content label style
- Adjust the style of the message card and message information input box on the message blessing page
- Adjust the display width of the front-end PC card for love events
- Adjust the statistics icon on the background home page
- Change the front page element animation effect (fade in)
- Enhanced front-end message blessing form verification
- Optimized the problem of slow loading of the front-end message blessing page
- Optimized front-end alert pop-up style
- Optimized front sidebar slider style
- Optimize the front end Love Photo card style
- Optimize the display style of some background pages
- Fixed Sql injection problems on some background pages
- Fixed authentication problems on some background pages
- Fixed the word limit of message blessing message content
- Fixed multiple front-end text overflow issues
- Added support for emojis in the title of love events (emojis)


------------


### LikeGirl 5.0.0

* Written in front of the modification of copyright I suggest you do not use disrespect for other people's results very shameful
* Added front-end full-site pjax unlimited loading technology
* Added asynchronous front and back end Ajax data request technology
* Added Gaussian blur switch for front head avatar background
* Added front-end Pjax unlimited load switch
* Added a security code is required to modify sensitive information
* Added custom front-end global CSS styles
* Added custom front-end header global content (can add css external links or other content)
* Added custom front-end bottom global content (can add js links or other content)
* Optimized the backend message page content/quantity display too long
* Optimize back-end data encoding for html character escape
* Optimize some page database preprocessing content
* Optimized some front end page loading animation effects
* Optimize reminder pop-ups using open source plugins primarily for aesthetics
* Optimize the front-end message board part of the CSS style data to get judgment
* Fixed "??? "display of Chinese content in database content web host/space
* Fixed the problem that the background management login page determines special characters in the password
* Repair website record number click can not jump to the Ministry of Industry and Information Technology official website
* Again, I wrote this project just to practice my skills without any thought of earning a penny. It is forbidden to sell in any way and be responsible for all consequences


------------

#### Usage instructions

- The basic syntax of HTML tags must be understood when writing articles
- You can search Baidu information to learn
- After deployment, there will be a default article to refer to the writing format

#### Edible method

- Open the admin folder in the root directory
- Then find the 'Config_DB.php' file open and follow the comment prompts to change to your database related information
- Please fill in the security code carefully as far as possible to set "complex difficult to guess" to change the password and other sensitive information need to enter the security code
- Finally import sql file to database (' love20240612.sql ')
- Default password: admin/lovezz


#### Feedback

Welcome to Like_Girl V5.1.0 (final version)
- If you encounter bugs or suggestions during use, please feedback to the mailbox. If you do not reply for more than '2 hours', you can add QQ friends for consultation and feedback
- mail@kikiw.cn
#### If the current project is helpful to you can scan the code sponsorship
! [payment code] (https://img.gejiba.com/images/b5e058f6f3c2ce6bd9d3ab4205aa0bac.png)